<?php

namespace App\CoreModel;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    public $table = 'schools';
}
