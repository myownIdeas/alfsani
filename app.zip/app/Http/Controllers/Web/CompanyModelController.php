<?php
namespace App\Http\Controllers\Web;


use App\Company;

use App\CompanyModel;
use App\Http\Response\Response\WebResponse;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request as Requestt;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;


class CompanyModelController  extends Controller
{
    public $response;
    public $request ="";
    public $companyModel ="";
    public $company = '';
    public function __construct(WebResponse $webResponse)
    {
        $this->response = $webResponse;
        $this->companyModel  = new CompanyModel();
        $this->company  = new company();
    }
    public function index()
    {

        return $this->response->setView("web.company_model.create")->respond(["data"=>[
        'companies'=>$this->company ->where('parent_category',0)->get()
        ]]);
    }
    public function listingPage()
    {
        $modelWithItems = DB::table('company_item')
           ->join('company', 'company.id', '=', 'company_item.company_id')
           ->join('company as model', 'model.id', '=', 'company_item.model_id')
            ->select('company.name', 'company_item.*','model.name as modelName')
            ->groupBy('company_id')
            ->get();
        return $this->response->setView("web.company_model.listing")->respond(["data"=>[
            'modelWithItems'=>$modelWithItems
        ]]);
    }
    public function subCategoryList(Requestt $request)
    {

        return json_encode($this->companyModel ->where('parent_category',$request->itemId)->get());
    }


    public function edit(Requestt $request){
        $companyModel  = $this->companyModel ->find($request->company_id);
       return $this->response->setView("web.companyModel .update")->respond(["data"=>[
           'companyModel '=>$companyModel
        ]]);
    }
    public function create(Requestt $request)
    {

         $items = explode(',',$request->get('items'));
        foreach($items as $item) {

            $companyModel = new companyModel();
            $companyModel->company_id = $request->company_id;
            $companyModel->model_id = $request->model_id;
            $companyModel->year = $request->year;
            $companyModel->item = $item;
            $companyModel->save();
        }
         return $this->index();


    }

    public function update(Requestt $request)
    {
        $companyModel  = $this->companyModel ->find($request->companyModelid);
        $companyModel ->name = $request->name;
        $companyModel ->save();
        return Redirect::back();
    }
    public function delete(Requestt $request)
    {
        $city = $this->city->find($request->city_id);
        $city->is_deleted = 1;
        $city->save();
        return $this->listingPage();
    }

    public function addItems(){
        return $this->response->setView("web.item.create")->respond(["data"=>[
            'companies'=>$this->company ->where('parent_category',0)->get()
        ]]);
    }

    public function insertItems(Requestt $request){
        $items = new CompanyModel();
        $final = [];
       foreach($request->itemName as $key=>$itme_price){
           $final[] =[
            'company_id' => $request->company_id,
            'first_model' => $request->model_id,
            'second_model' => $request->second_model,
            'third_model' => $request->third_model,
            'item' => $request->itemName[$key],
            'price' => $request->itemPrice[$key],
       ];

    }
        $items->insert($final);

        return $this->addItems();
    }

    public function itemListing(Requestt $request){

    }
    public function itemListingPage()
    {
        $modelWithItems = DB::table('company_item')
            ->join('company', 'company.id', '=', 'company_item.company_id')
            ->join('company as f_model', 'f_model.id', '=', 'company_item.first_model')
            ->join('company as s_model', 's_model.id', '=', 'company_item.second_model')
            ->join('company as t_model', 't_model.id', '=', 'company_item.third_model')
            ->select('company.name', 'company_item.*','f_model.name as fName','s_model.name as sName','t_model.name as tName')
            ->groupBy('company_item.company_id')
            ->get();

        return $this->response->setView("web.item.listing")->respond(["data"=>[
            'modelWithItems'=>$modelWithItems
        ]]);
    }

}
