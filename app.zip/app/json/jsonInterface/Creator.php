<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/16/2017
 * Time: 9:39 PM
 */

namespace App\json\jsonInterface;


Interface Creator
{
    public function creator();
}