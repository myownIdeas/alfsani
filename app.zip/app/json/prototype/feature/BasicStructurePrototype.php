<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/18/2017
 * Time: 7:58 PM
 */

namespace App\json\prototype\feature;


class BasicStructurePrototype
{
    public $categoryId=0;
    public $json;

}