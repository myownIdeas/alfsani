<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/16/2017
 * Time: 9:48 PM
 */

namespace App\json\prototype\feature\FeatureSectionPrototype;


class FeatureSectionPrototype
{
    public $id =0;
    public $sectionName =[];
    public $features =[];
}