<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/16/2017
 * Time: 10:00 PM
 */

namespace App\json\prototype\feature\featurePrototype;


class featurePrototype
{
    public $id=0;
    public $name='';
    public $value='';
    public $htmlType='';
    public $label='';
    public $sectionId = 0;
    public $sectionName = "";
    public $possibleValues=[];
    public $html;
}