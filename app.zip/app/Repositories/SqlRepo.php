<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/9/2017
 * Time: 9:14 AM
 */

namespace App\Repositories;


class SqlRepo extends Repository
{

}