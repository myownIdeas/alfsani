<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/9/2017
 * Time: 9:37 AM
 */

namespace App\Repositories;


class Repository
{

}