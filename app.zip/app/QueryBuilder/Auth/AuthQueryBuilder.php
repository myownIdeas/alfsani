<?php
/**
 * Created by PhpStorm.
 * User: Waqas
 * Date: 5/10/2017
 * Time: 8:40 AM
 */

namespace App\QueryBuilder\Auth;


use App\QueryBuilder\QueryBuilder;

class AuthQueryBuilder extends QueryBuilder
{

}