@extends('include.layout')
@section('content')



        <section class="sub-header">
            <div class="container-fluid">
                <div class="subheader-main">
                    <h2>Dashboard</h2>
                    <div class="breadcrumb-link ml-3">
                        <a href="#"><i class="far fa-envelope"></i> Items Listing</a>
                    </div>
                </div>
            </div>
        </section>
        <div class="container-fluid">
            <div class="content-box">
                <table id="example" class="table table-striped table-bordered listing-table" style="width:100%">
                    <thead>
                    <tr>
                        <th>Company Name</th>
                        <th>Model Name </th>
                        <th>Year </th>
                        <th> </th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($response['data']['modelWithItems'] as $modelItem)
                    <tr>

                        <td>{{$modelItem->name}}</td>
                        <td>{{$modelItem->modelName}} </td>
                        <td><a href="#" onclick="showItems()"> show Items</a></td>
                        <td>{{$modelItem->created_at}}</td>
                        <td>
                           {{-- <a href="{{URL::to('edit_company').'?company_id='.$modelItem->id}}"><i class="fas fa-edit"></i></a>--}}
                           {{-- <a href="{{URL::to('delete_item').'?item_id='.$item->id}}" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a>--}}

                        </td>
                    </tr>
                  @endforeach

                    </tbody>

                </table>
            </div>

        </div>




@endsection